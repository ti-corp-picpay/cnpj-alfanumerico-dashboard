# 🎯 Projeto Pronto - Dashboard Automático

## ✅ O que foi criado

Projeto completo de automação do dashboard em:
`C:\Users\NL159124\Downloads\cptechc-491-dashboard-automation\`

### Arquivos

| Arquivo | Descrição |
|---------|-----------|
| `generate_dashboard.py` | Script principal - busca dados do Jira |
| `html_generator.py` | Gera HTML dinâmico |
| `template.html` | Template base (seu dashboard atual) |
| `.github/workflows/update-dashboard.yml` | GitHub Actions (roda todo dia) |
| `requirements.txt` | Dependências Python |
| `README.md` | Documentação completa |
| `SETUP.md` | **Guia rápido de 5 min** |
| `ARCHITECTURE.md` | Como funciona por baixo |
| `.env.example` | Exemplo de configuração |
| `.gitignore` | O que não versionar |

## 🚀 Próximos Passos (Você Faz)

### 1. Criar Repo no GitHub (2 min)
- https://github.com/new
- Nome: `cptechc-491-dashboard`
- **Privado**

### 2. Adicionar Secrets (2 min)
- Settings → Secrets → Actions
- `JIRA_EMAIL`: natali.lee@picpay.com
- `JIRA_TOKEN`: (gere um novo em https://id.atlassian.com/manage-profile/security/api-tokens)

### 3. Push do Código (1 min)

```powershell
cd C:\Users\NL159124\Downloads\cptechc-491-dashboard-automation

git init
git add .
git commit -m "feat: dashboard automatizado"
git branch -M main
git remote add origin https://github.com/SEU_USERNAME/cptechc-491-dashboard.git
git push -u origin main
```

### 4. Ativar Actions (30s)
- Aba **Actions** → Enable workflows
- **Run workflow** (testar)

## ✨ Resultado

Dashboard atualiza **sozinho todo dia às 8h** com:
- ✅ Dados frescos do Jira
- ✅ Cálculo automático de risco (prazo + operacional)
- ✅ Burndown atualizado
- ✅ Issues sem data
- ✅ Progresso por squad
- ✅ Mesma URL (não quebra links)

## 📌 URL Final

Será sempre a mesma:
https://nitro-link.ppay.me/html/0d9a2928cea6/CPTECHC-491-dashboard-final.html

## 🔧 Manutenção

**Zero.** Roda sozinho. Se quiser ajustar algo:
- Edite `html_generator.py`
- Commit e push
- Próxima execução já usa a versão nova

---

**Tempo total de setup:** ~5 minutos  
**Custo mensal:** R$ 0,00  
**Atualização:** Automática, diária

Siga o **SETUP.md** pra fazer o setup rápido! 🐺
