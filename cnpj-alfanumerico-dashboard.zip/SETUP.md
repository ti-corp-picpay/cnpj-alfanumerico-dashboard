# Setup Rápido - Dashboard Automático

## ⚡ 5 Minutos de Setup

### 1️⃣ Criar repo no GitHub

1. Acesse: https://github.com/new
2. Nome: `cnpj-alfanumerico-dashboard`
3. **Privado** ✅
4. Não inicializar com README (já temos)
5. **Create repository**

---

### 2️⃣ Gerar Token do Jira

1. Acesse: https://id.atlassian.com/manage-profile/security/api-tokens
2. **Create API token**
3. Nome: `Dashboard Automation`
4. **Copie o token** (só aparece uma vez!)

---

### 3️⃣ Adicionar Secrets no GitHub

No repo criado, acesse: **Settings → Secrets and variables → Actions**

Clique em **New repository secret** e adicione:

| Name | Value |
|------|-------|
| `JIRA_EMAIL` | `natali.lee@picpay.com` |
| `JIRA_TOKEN` | (cole o token que você gerou) |

---

### 4️⃣ Fazer Push do Código

Abra PowerShell e rode:

```powershell
cd C:\Users\NL159124\Downloads\cptechc-491-dashboard-automation

git init
git add .
git commit -m "feat: dashboard automatizado CPTECHC-491"
git branch -M main
git remote add origin https://github.com/SEU_USERNAME/cptechc-491-dashboard.git
git push -u origin main
```

⚠️ **Substitua `SEU_USERNAME`** pelo seu usuário do GitHub!

---

### 5️⃣ Ativar e Testar

1. Acesse a aba **Actions** no repo
2. Clique em **I understand my workflows, go ahead and enable them**
3. Selecione o workflow **Update Dashboard**
4. Clique em **Run workflow** → **Run workflow**
5. Aguarde ~30s
6. Veja os logs pra confirmar que funcionou

---

## ✅ Pronto!

A partir de agora, o dashboard atualiza **automaticamente todo dia às 8h**.

Link do dashboard: https://nitro-link.ppay.me/html/0d9a2928cea6/792107848e2b9b09-CPTECHC-491-dashboard-final.html

---

## 🔧 Se Algo Der Errado

**Python não instalado localmente?**
- Sem problema! O GitHub Actions tem Python instalado.
- Só precisa testar no Actions mesmo.

**Erro de permissão no Jira?**
- Verifique se o token está correto
- Gere um novo token se necessário

**Workflow não aparece?**
- Verifique se o arquivo está em `.github/workflows/update-dashboard.yml`
- Faça push novamente

---

**Dúvidas?** Chama o Wolf! 🐺
