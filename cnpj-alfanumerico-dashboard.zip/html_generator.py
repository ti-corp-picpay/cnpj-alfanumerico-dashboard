#!/usr/bin/env python3
"""
HTML Generator - Gera dashboard HTML com dados dinâmicos do Jira
"""

def generate_html(data, risk):
    """Gera HTML completo do dashboard"""
    
    progress_pct = round((data['done'] / data['total']) * 100) if data['total'] > 0 else 0
    inject_pct = round((data['inject'] / data['baseline']) * 100) if data['baseline'] > 0 else 0
    
    # Calcular progresso por squad
    squad_stats = []
    for squad in ['PLD', 'COMFA', 'HCM', 'GEL', 'CFERP', 'TICORP', 'EFCONT', 'MELCOR']:
        if squad in data['squad_total']:
            total = data['squad_total'][squad]
            done = data['squad_done'].get(squad, 0)
            pending = data['squad_pending'].get(squad, 0)
            pct = round((done / total) * 100) if total > 0 else 0
            squad_stats.append({
                'name': squad,
                'done': done,
                'total': total,
                'pending': pending,
                'pct': pct
            })
    
    # Ordenar por % de conclusão
    squad_stats.sort(key=lambda x: x['pct'], reverse=True)
    
    # Gerar linhas da tabela de squads
    squad_rows = ''
    for s in squad_stats:
        status_class = 'success' if s['pct'] >= 70 else ('warning' if s['pct'] >= 50 else 'danger')
        status_label = 'Concluída' if s['pct'] == 100 else ('Progresso' if s['pct'] >= 50 else 'Crítica')
        row_class = ' class="row-danger"' if s['pct'] < 50 else ''
        
        in_prog = s['total'] - s['done'] - data['squad_pending'].get(s['name'], 0)
        backlog = data['squad_pending'].get(s['name'], 0)
        
        squad_rows += f'''
            <tr{row_class}>
              <td><strong>{s['name']}</strong><br><span style="font-size:12px;color:var(--text-muted)">{get_squad_desc(s['name'])}</span></td>
              <td>
                <div class="progress-mini">
                  <div class="progress-mini-bar"><div class="progress-mini-fill" style="width:{s['pct']}%;background:var(--{status_class})"></div></div>
                  <span class="progress-mini-text" style="color:var(--{status_class})">{s['pct']}%</span>
                </div>
              </td>
              <td>{s['done']}</td>
              <td>{max(0, in_prog)}</td>
              <td>{backlog}</td>
              <td><span class="table-badge {status_class}">{status_label}</span></td>
              <td><a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20project%20%3D%20{s['name']}" target="_blank" class="table-link">Ver →</a></td>
            </tr>'''
    
    # Gerar cards de issues sem data por squad
    no_date_cards = ''
    for squad, count in sorted(data['no_duedate_by_squad'].items(), key=lambda x: x[1], reverse=True)[:4]:
        color = 'danger' if count >= 5 else 'warning' if count >= 3 else 'info'
        no_date_cards += f'''
            <a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20project%20%3D%20{squad}%20AND%20duedate%20IS%20EMPTY%20AND%20status%20NOT%20IN%20(Done%2C%20Cancelled)" target="_blank" style="text-decoration: none; color: inherit;">
              <div style="padding: 16px; background: var(--bg); border-radius: 10px; text-align: center;">
                <div style="font-size: 24px; font-weight: 700; color: var(--{color});">{count}</div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">{squad}</div>
              </div>
            </a>'''
    
    # Data de atualização
    now = datetime.now().strftime('%d/%m/%Y às %H:%M')
    
    html = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CPTECHC-491 — Status Report</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
''' + get_css() + '''
</head>
<body>

<div class="container">

  <!-- HERO -->
  <div class="hero">
    <div class="hero-content">
      <div class="hero-badge">
        📊 Dashboard Executivo • Atualizado: {now}
      </div>
      <h1 class="hero-title">CNPJ Alfanumérico</h1>
      <p class="hero-subtitle">CPTECHC-491 — Adequações Multi-Squad para Suporte a CNPJ de 14 Caracteres</p>
      
      <div class="hero-stats">
        <a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20status%20%3D%20Done" target="_blank" class="hero-stat">
          <div class="hero-stat-value">{progress_pct}%</div>
          <div class="hero-stat-label">Progresso</div>
          <span class="hero-stat-link">{data['done']} de {data['total']} →</span>
        </a>
        <a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20created%20%3C%3D%202025-12-31" target="_blank" class="hero-stat">
          <div class="hero-stat-value">{data['baseline']}</div>
          <div class="hero-stat-label">Planejado</div>
          <span class="hero-stat-link">Baseline →</span>
        </a>
        <a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20created%20%3E%3D%202026-01-01" target="_blank" class="hero-stat">
          <div class="hero-stat-value">{data['inject']}</div>
          <div class="hero-stat-label">Inject</div>
          <span class="hero-stat-link">+{inject_pct}% escopo →</span>
        </a>
        <a href="https://picpay.atlassian.net/issues/?jql=key%20IN%20(COMFA-698%2C%20COMFA-702%2C%20HCM-788)" target="_blank" class="hero-stat">
          <div class="hero-stat-value">{len(data['replanned'])}</div>
          <div class="hero-stat-label">Replanejadas</div>
          <span class="hero-stat-link">Due date alterada →</span>
        </a>
        <a href="https://picpay.atlassian.net/issues/?jql=(parent%20%3D%20CPTECHC-491%20OR%20parent%20IN%20portfolioChildIssuesOf(%22CPTECHC-491%22))%20AND%20status%20%3D%20Cancelled" target="_blank" class="hero-stat">
          <div class="hero-stat-value">{data['cancelled']}</div>
          <div class="hero-stat-label">Canceladas</div>
          <span class="hero-stat-link">Removidas →</span>
        </a>
      </div>
    </div>
  </div>

  <!-- ... resto do HTML será inserido aqui ... -->
  
  <div class="footer">
    <div>
      <a href="https://picpay.atlassian.net/browse/CPTECHC-491" target="_blank">CPTECHC-491</a> • Dashboard Executivo
    </div>
    <div>
      Atualizado em {now} • TI Corporativa • Dados: Jira API
    </div>
  </div>

</div>

</body>
</html>'''
    
    return html

def get_squad_desc(squad):
    """Retorna descrição do squad"""
    descs = {
        'PLD': 'PLD e Compliance',
        'COMFA': 'Compras & Facilities',
        'HCM': 'RH HCM',
        'GEL': 'Auditoria, Jurídico',
        'CFERP': 'Operações Financeiras',
        'TICORP': 'Riscos Financeiros',
        'EFCONT': 'Eficiência Contábil',
        'MELCOR': 'Melhorias Estruturantes'
    }
    return descs.get(squad, squad)

def get_css():
    """Retorna todo o CSS do dashboard"""
    return '''<style>
:root {
  /* PicPay Brand Colors */
  --picpay: #21C25E;
  --picpay-dark: #1A9F4A;
  --picpay-light: #E8F7ED;
  
  /* Neutrals - Light Theme */
  --bg: #F5F5F5;
  --card: #FFFFFF;
  --border: #E0E0E0;
  --text: #1A1A1A;
  --text-sec: #666666;
  --text-muted: #999999;
  
  /* Status Colors */
  --success: #21C25E;
  --warning: #F5A623;
  --danger: #E53935;
  --info: #1E88E5;
  --purple: #7B1FA2;
  
  /* Dims */
  --success-dim: rgba(33,194,94,.1);
  --warning-dim: rgba(245,166,35,.1);
  --danger-dim: rgba(229,57,53,.1);
  --info-dim: rgba(30,136,229,.1);
  --purple-dim: rgba(123,31,162,.1);
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  font-family: 'Inter', -apple-system, sans-serif;
  background: var(--bg);
  color: var(--text);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 32px 24px;
}

/* ... resto do CSS ... */

@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.6; transform: scale(1.1); }
}
</style>'''

if __name__ == '__main__':
    # Teste simples
    data = {
        'total': 104,
        'done': 69,
        'pending': 33,
        'baseline': 62,
        'inject': 42,
        'cancelled': 2,
        'replanned': []
    }
    risk = {}
    
    html = generate_html(data, risk)
    print(f"HTML gerado: {len(html)} caracteres")
