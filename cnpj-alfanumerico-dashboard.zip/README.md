# Dashboard CNPJ Alfanumérico - Automação

Dashboard executivo do projeto CNPJ Alfanumérico (iniciativa CPTECHC-491), atualizado automaticamente via GitHub Actions.

## 🎯 O que faz

- Busca dados do Jira via API (todo dia às 8h)
- Gera HTML atualizado com métricas em tempo real
- Faz upload pro Nitro Link
- Dashboard sempre atualizado sem intervenção manual

## 🚀 Setup

### 1. Criar repositório no GitHub

```bash
# Criar repo privado no GitHub (via web)
# Nome sugerido: cnpj-alfanumerico-dashboard
```

### 2. Adicionar Secrets no GitHub

Acesse: `Settings → Secrets and variables → Actions → New repository secret`

Adicione 3 secrets:

| Nome | Valor | Como obter |
|------|-------|------------|
| `JIRA_EMAIL` | seu.email@picpay.com | Seu email do Jira |
| `JIRA_TOKEN` | ATATT3xFf... | [Gerar aqui](https://id.atlassian.com/manage-profile/security/api-tokens) |
| `NITRO_TOKEN` | (se necessário) | Token do Nitro Link (se houver autenticação) |

### 3. Fazer push do código

```bash
cd C:\Users\NL159124\Downloads\cptechc-491-dashboard-automation

git init
git add .
git commit -m "feat: setup inicial do dashboard automatizado"
git branch -M main
git remote add origin https://github.com/SEU_USER/cptechc-491-dashboard.git
git push -u origin main
```

### 4. Ativar GitHub Actions

- Acesse a aba **Actions** no repo
- Clique em **Enable workflows**
- Clique em **Run workflow** pra testar manualmente

## 📅 Agendamento

O dashboard atualiza automaticamente:
- **Todo dia às 8h** (horário de Brasília)
- Ou **manualmente** via botão "Run workflow"

## 📁 Estrutura

```
.
├── .github/
│   └── workflows/
│       └── update-dashboard.yml    # GitHub Actions workflow
├── generate_dashboard.py           # Script principal
├── requirements.txt                # Dependências Python
├── template.html                   # Template do HTML (próximo passo)
└── README.md                       # Este arquivo
```

## 🔧 Desenvolvimento Local

```bash
# Instalar dependências
pip install -r requirements.txt

# Configurar env vars
export JIRA_EMAIL="seu.email@picpay.com"
export JIRA_TOKEN="seu_token_aqui"

# Rodar localmente
python generate_dashboard.py
```

## 📊 Dados Gerados

O script gera `dashboard-data.json` com:
- Total de issues, done, pendentes
- Baseline vs Inject
- Issues sem due date por squad
- Prioridades
- Burndown mensal
- Cálculo de risco (prazo + operacional)

## 🐛 Troubleshooting

**Erro de autenticação:**
- Verifique se os secrets estão corretos
- Gere um novo token do Jira se necessário

**Workflow não roda:**
- Verifique se GitHub Actions está habilitado no repo
- Veja os logs na aba Actions

**Dashboard não atualiza:**
- Veja os logs do workflow
- Teste rodando manualmente (Run workflow)

## 📝 TODO

- [ ] Implementar geração completa do HTML
- [ ] Script de upload pro Nitro Link
- [ ] Testes unitários
- [ ] Notificação no Slack quando houver mudanças críticas

## 🤝 Contribuindo

1. Faça suas alterações
2. Teste localmente
3. Commit e push
4. O workflow roda automaticamente

---

**Última atualização:** 19/03/2026
**Mantido por:** Time TICORP
