# Como Funciona - Arquitetura da Automação

## 📐 Diagrama de Fluxo

```
┌─────────────────┐
│  GitHub Actions │  ← Roda todo dia às 8h
│   (Scheduler)   │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  generate_dashboard.py              │
│  1. Busca dados do Jira (API)       │
│  2. Analisa métricas                │
│  3. Calcula riscos                  │
│  4. Salva dashboard-data.json       │
└────────┬────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  html_generator.py                  │
│  1. Lê dados do JSON                │
│  2. Renderiza template HTML         │
│  3. Gera dashboard atualizado       │
└────────┬────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│  Upload para Nitro Link             │
│  1. Sobrescreve arquivo existente   │
│  2. URL permanece a mesma           │
│  3. Dashboard sempre atualizado     │
└─────────────────────────────────────┘
```

## 📊 Dados Extraídos do Jira

| Dado | JQL Usado | Uso |
|------|-----------|-----|
| **Todas issues** | `parent = CPTECHC-491 OR parent IN portfolioChildIssuesOf("CPTECHC-491")` | Total, progresso |
| **Done** | `... AND status = Done` | Métricas de conclusão |
| **Pendentes** | `... AND status NOT IN (Done, Cancelled)` | O que falta |
| **Baseline** | `... AND created <= 2025-12-31` | Escopo inicial |
| **Inject** | `... AND created >= 2026-01-01` | Scope creep |
| **Sem data** | `... AND duedate IS EMPTY AND status NOT IN (Done, Cancelled)` | Risco operacional |
| **Por squad** | `... AND project = HCM` | Performance |
| **Burndown** | Agrupa por mês de `resolutiondate` | Gráfico |

## 🎯 Cálculo de Risco

### Risco de Prazo

```python
avg_velocity = média_últimos_3_meses
required_velocity = pendentes / meses_até_deadline

if avg_velocity >= required * 1.2:
    risco = BAIXO (verde)
elif avg_velocity >= required * 0.8:
    risco = MÉDIO (amarelo)
else:
    risco = ALTO (vermelho)
```

### Risco Operacional

```python
critical_count = issues com priority = Critical
no_date_count = issues sem due date

if critical >= 15 OR no_date >= 10:
    risco = ALTO (vermelho)
elif critical >= 8 OR no_date >= 5:
    risco = MÉDIO (amarelo)
else:
    risco = BAIXO (verde)
```

## 🔄 Atualização Automática

### GitHub Actions Schedule

```yaml
on:
  schedule:
    - cron: '0 11 * * *'  # 11h UTC = 8h BRT
  workflow_dispatch:       # Botão manual
```

### Variáveis Necessárias

```bash
JIRA_EMAIL=natali.lee@picpay.com
JIRA_TOKEN=ATATT...  # Secret no GitHub
```

## 🔗 Nitro Link Upload

O Nitro Link permite **sobrescrever** arquivos mantendo a mesma URL:
- Mesmo nome de arquivo → mesma URL
- Não precisa atualizar links
- Dashboard sempre no mesmo endereço

## 📝 Versionamento

O repo guarda histórico de:
- `dashboard-data.json` - dados brutos do Jira
- Commits do Actions mostram quando atualizou
- Diffs mostram o que mudou

## 🐛 Debugging

Se algo der errado:
1. Veja os logs na aba **Actions** do GitHub
2. Rode localmente: `python generate_dashboard.py`
3. Verifique se os secrets estão corretos

## 🚀 Evolução Futura

Fácil adicionar:
- [ ] Notificação no Slack quando risco mudar
- [ ] Gráficos adicionais (velocity chart, CFD)
- [ ] Comparação semana vs semana
- [ ] Previsão de conclusão com ML

---

**Tempo de execução:** ~30 segundos  
**Custo:** R$ 0,00 (GitHub Actions free tier)  
**Manutenção:** Zero (roda sozinho)
