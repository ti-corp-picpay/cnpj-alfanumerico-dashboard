@echo off
REM Script de teste local do dashboard

echo ========================================
echo  Dashboard CPTECHC-491 - Teste Local
echo ========================================
echo.

REM Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado. Instale Python 3.11+
    exit /b 1
)

REM Verificar se .env existe
if not exist .env (
    echo [AVISO] Arquivo .env nao encontrado
    echo Copie .env.example para .env e configure suas credenciais
    echo.
    echo   copy .env.example .env
    echo.
    pause
    exit /b 1
)

REM Instalar dependências
echo [1/3] Instalando dependencias...
pip install -q -r requirements.txt
if errorlevel 1 (
    echo [ERRO] Falha ao instalar dependencias
    exit /b 1
)

REM Carregar .env (PowerShell)
echo [2/3] Carregando variaveis de ambiente...
for /f "tokens=1,2 delims==" %%a in (.env) do (
    set %%a=%%b
)

REM Rodar script
echo [3/3] Gerando dashboard...
python generate_dashboard.py
if errorlevel 1 (
    echo [ERRO] Falha ao gerar dashboard
    exit /b 1
)

echo.
echo ========================================
echo  Sucesso!
echo ========================================
echo.
echo Arquivo gerado: dashboard-data.json
echo.
pause
